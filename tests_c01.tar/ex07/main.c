/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 19:36:40 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/12 19:50:50 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size);

void	print_array(int *a, int size)
{
	int	i;

	if (size < 1)
		return ;
	printf("%d", a[0]);
	i = 1;
	while (i < size)
	{
		printf(", %d", a[i]);
		i += 1;
	}
	printf("\n");
}

int	main(void)
{
	int	a[10];
	int	i;

	i = 0;
	while (i < 10)
	{
		a[i] = i;
		i += 1;
	}
	ft_rev_int_tab(a, 10);
	printf("swap 10\n");
	print_array(a, 10);
	ft_rev_int_tab(a, 3);
	printf("swap 3\n");
	print_array(a, 10);
	ft_rev_int_tab(a, 1);
	printf("swap 1\n");
	print_array(a, 10);
	ft_rev_int_tab(a, 2);
	printf("swap 2\n");
	print_array(a, 10);
	ft_rev_int_tab(a, 0);
	printf("swap 0\n");
	print_array(a, 10);
}
