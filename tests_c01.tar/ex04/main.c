/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 18:54:18 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/12 19:04:14 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b);

int	main(void)
{
	int	a;
	int	b;

	a = 42;
	b = 5;
	printf("%d/%d: ", a, b);
	ft_ultimate_div_mod(&a, &b);
	printf("%d, r. %d\n", a, b);
	a = -42;
	b = 5;
	printf("%d/%d: ", a, b);
	ft_ultimate_div_mod(&a, &b);
	printf("%d, r. %d\n", a, b);
}
