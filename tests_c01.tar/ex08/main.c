/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 20:10:36 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/12 20:16:51 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_sort_int_tab(int *tab, int size);

void	print_array(int *a, int size)
{
	int	i;

	if (size < 1)
		return ;
	printf("%d", a[0]);
	i = 1;
	while (i < size)
	{
		printf(", %d", a[i]);
		i += 1;
	}
	printf("\n");
}

int	main(void)
{
	int	a[10];
	int	i;

	i = 0;
	while (i < 10)
	{
		a[i] = 20 - i;
		i += 1;
	}
	printf("intial array:\n");
	print_array(a, 10);
	ft_sort_int_tab(a, 10);
	printf("sorted array:\n");
	print_array(a, 10);
	i = 0;
	srand(44);
	while (i < 10)
	{
		a[i] = rand() % 42 + 10;
		i += 1;
	}
	printf("intial array:\n");
	print_array(a, 10);
	ft_sort_int_tab(a, 10);
	printf("sorted array:\n");
	print_array(a, 10);
}
