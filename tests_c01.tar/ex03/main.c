/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 18:54:18 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/12 18:58:38 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

int	main(void)
{
	int	a;
	int	b;
	int	div;
	int	mod;

	a = 42;
	b = 5;
	ft_div_mod(a, b, &div, &mod);
	printf("%d/%d: %d, r. %d\n", a, b, div, mod);
	a = -42;
	b = 5;
	ft_div_mod(a, b, &div, &mod);
	printf("%d/%d: %d, r. %d\n", a, b, div, mod);
}
