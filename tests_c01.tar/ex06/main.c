/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/12 19:06:31 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/12 19:13:30 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str);

int	main(void)
{
	printf("11:%d:hello world\n", ft_strlen("hello world"));
	printf("11:%d:hello\nworld\n", ft_strlen("hello\nworld"));
	printf("11:%d:hello0world\n", ft_strlen("hello0world"));
	printf("0:%d:\n", ft_strlen(""));
}
