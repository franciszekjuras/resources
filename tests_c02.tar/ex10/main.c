/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 08:57:52 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 20:34:48 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int n);

int	main(void)
{
	char	*src;
	char	dest[20];
	int		r;

	src = "abcdef\0";
	dest[6] = 'g';
	dest[7] = 'h';
	r = ft_strlcpy(dest, src, 6);
	write(1, dest, 8);
	write(1, "\n", 1);
	printf("%d\n", r);
	r = ft_strlcpy(dest, src, 7);
	write(1, dest, 8);
	write(1, "\n", 1);
	printf("%d\n", r);
	r = ft_strlcpy(dest, src, 20);
	write(1, dest, 8);
	write(1, "\n", 1);
	printf("%d\n", r);
	write(1, "\nTest NULL: ", 12);
	r = ft_strlcpy(NULL, "xdd", 0);
	write(1, "OK\n", 3);
	printf("%d\n", r);
}
