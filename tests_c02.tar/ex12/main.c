/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 10:56:39 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/14 16:00:24 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	char	*end;

	end = str;
	while (*end != 0)
		end += 1;
	return (end - str);
}

void	*ft_print_memory(void *addr, unsigned int size);

int	main(void)
{
	char	str1[50] = "abcdefghijklmnopqrstuvwxyz\n";
	char	str2[50] = "\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"
		"\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x7f\xff";

	ft_print_memory(((void *)str1), ft_strlen(str1) + 1);
	ft_print_memory(((void *)str2), ft_strlen(str2));
	ft_print_memory(((void *)str2), 32);
}
