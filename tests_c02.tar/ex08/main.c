/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 18:53:13 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 19:10:57 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strlowcase(char *str);

int	main(void)
{
	char	str[20] = "HELLO WORLD\n";
	char	str2[35] = "<=**he\tLLo\nwORld1234567890**=>\n";

	printf("%s", ft_strlowcase(str));
	printf("%s", ft_strlowcase(str2));
	printf("Test empty: ");
	ft_strlowcase("");
	printf("OK\n");
}
