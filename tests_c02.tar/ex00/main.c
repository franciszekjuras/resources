/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 08:57:52 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 09:09:12 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strcpy(char *dest, char *src);

int	main(void)
{
	char	*src;
	char	dest[20];

	src = "abc\0\0\0d\n";
	dest[3] = 'x';
	ft_strcpy(dest, src);
	write(1, dest, 4);
	write(1, "\n", 1);
}
