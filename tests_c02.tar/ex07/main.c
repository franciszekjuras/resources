/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 18:53:13 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 19:11:13 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strupcase(char *str);

int	main(void)
{
	char	str[20] = "hello world\n";
	char	str2[35] = "<=**he\tLLo\nwORld1234567890**=>\n";

	printf("%s", ft_strupcase(str));
	printf("%s", ft_strupcase(str2));
	printf("Test empty: ");
	ft_strupcase("");
	printf("OK\n");
}
