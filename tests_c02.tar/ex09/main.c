/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 18:53:13 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 19:49:30 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcapitalize(char *str);

int	main(void)
{
	char	str[20] = "hELlO 1A3w~ORLD\n";
	char	str2[35] = "<=**he\tLLo\nwORld1234567890**=>\n";
	char	str3[80] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un\n";

	printf("%s", ft_strcapitalize(str));
	printf("%s", ft_strcapitalize(str2));
	printf("%s", ft_strcapitalize(str3));
	printf("Test empty: ");
	ft_strcapitalize("");
	printf("OK\n");
}
