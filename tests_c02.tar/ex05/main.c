/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 09:23:38 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:31:11 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_uppercase(char *str);

void	print_bool(int v)
{
	if (v)
		write(1, "T", 1);
	else
		write(1, "F", 1);
}

int	main(void)
{
	write(1, "FFFTFFTFT\n", 10);
	print_bool(ft_str_is_uppercase("IS SPACE UPPERCASE"));
	print_bool(ft_str_is_uppercase("ISTHISUPPERCASE?"));
	print_bool(ft_str_is_uppercase("isthisuppercase"));
	print_bool(ft_str_is_uppercase("THIZISUPPERCASE"));
	print_bool(ft_str_is_uppercase("ThiZiSuppercase"));
	print_bool(ft_str_is_uppercase("THIZIS[NOT]UPPERCASE"));
	print_bool(ft_str_is_uppercase("QWERTYUIOPASDFGHJKLZXCVBNM"));
	print_bool(ft_str_is_uppercase("qwertyuiopasdfghjklzxcvbnm"));
	print_bool(ft_str_is_uppercase(""));
	write(1, "\n", 1);
}
