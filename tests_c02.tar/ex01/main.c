/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 08:57:52 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:10:46 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int	main(void)
{
	char	*src;
	char	dest[20];

	src = "abc\0def\n";
	dest[3] = 'x';
	ft_strncpy(dest, src, 3);
	write(1, dest, 4);
	write(1, "\n", 1);
	ft_strncpy(dest + 4, src + 4, 3);
	ft_strncpy(dest, src, 7);
	write(1, dest, 7);
	write(1, "\nTest NULL: ", 12);
	ft_strncpy(NULL, NULL, 0);
	write(1, "OK\n", 3);
}
