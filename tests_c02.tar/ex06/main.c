/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 09:23:38 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:51:09 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_printable(char *str);

void	print_bool(int v)
{
	if (v)
		write(1, "T", 1);
	else
		write(1, "F", 1);
}

int	main(void)
{
	write(1, "TFTTTFFFT\n", 10);
	print_bool(ft_str_is_printable("IS SPACE printable"));
	print_bool(ft_str_is_printable("IS\tTHIS\nprintable?"));
	print_bool(ft_str_is_printable("ThiZiSprintable"));
	print_bool(ft_str_is_printable("**THIZIS[indeed]printable**"));
	print_bool(ft_str_is_printable(" !\"%%#$&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	print_bool(ft_str_is_printable("qwertyuiopasdfghjklzxcvbnm\x7f"));
	print_bool(ft_str_is_printable("\x01"));
	print_bool(ft_str_is_printable("\x1f"));
	print_bool(ft_str_is_printable(""));
	write(1, "\n", 1);
}
