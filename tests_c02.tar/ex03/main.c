/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 09:23:38 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:32:30 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_numeric(char *str);

void	print_bool(int v)
{
	if (v)
		write(1, "T", 1);
	else
		write(1, "F", 1);
}

int	main(void)
{
	write(1, "TFFFFT\n", 7);
	print_bool(ft_str_is_numeric("0123456789"));
	print_bool(ft_str_is_numeric("-42"));
	print_bool(ft_str_is_numeric("42.13"));
	print_bool(ft_str_is_numeric("4 2"));
	print_bool(ft_str_is_numeric("0a"));
	print_bool(ft_str_is_numeric(""));
	write(1, "\n", 1);
}
