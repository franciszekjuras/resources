/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 09:23:38 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:32:59 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_alpha(char *str);

void	print_bool(int v)
{
	if (v)
		write(1, "T", 1);
	else
		write(1, "F", 1);
}

int	main(void)
{
	write(1, "FFFTFTT\n", 8);
	print_bool(ft_str_is_alpha("is space alpha"));
	print_bool(ft_str_is_alpha("isthisalpha?"));
	print_bool(ft_str_is_alpha("ThiZiSAlpha?"));
	print_bool(ft_str_is_alpha("ThiZiSAlpha"));
	print_bool(ft_str_is_alpha("ThiZiS[not]Alpha"));
	print_bool(ft_str_is_alpha("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"));
	print_bool(ft_str_is_alpha(""));
	write(1, "\n", 1);
}
