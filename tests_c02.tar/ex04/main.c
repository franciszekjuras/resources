/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fjuras <fjuras@student.42wolfsburg.de>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/13 09:23:38 by fjuras            #+#    #+#             */
/*   Updated: 2022/02/13 18:31:24 by fjuras           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_lowercase(char *str);

void	print_bool(int v)
{
	if (v)
		write(1, "T", 1);
	else
		write(1, "F", 1);
}

int	main(void)
{
	write(1, "FFFTFFFTT\n", 10);
	print_bool(ft_str_is_lowercase("is space lowercase"));
	print_bool(ft_str_is_lowercase("isthislowercase?"));
	print_bool(ft_str_is_lowercase("isthislowercasE"));
	print_bool(ft_str_is_lowercase("thizislowercase"));
	print_bool(ft_str_is_lowercase("ThiZiSlowercase"));
	print_bool(ft_str_is_lowercase("ThiZiS[not]lowercase"));
	print_bool(ft_str_is_lowercase("QWERTYUIOPASDFGHJKLZXCVBNM"));
	print_bool(ft_str_is_lowercase("qwertyuiopasdfghjklzxcvbnm"));
	print_bool(ft_str_is_lowercase(""));
	write(1, "\n", 1);
}
